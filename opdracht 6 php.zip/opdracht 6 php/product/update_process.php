<?php
include 'Product.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $productId = $_POST['product_id'];
    $naam = $_POST['naam'];
    $prijs = $_POST['prijs'];
    $omschrijving = $_POST['omschrijving'];

    $product = new Product($dbh);
    $updateSuccess = $product->updateProduct($productId, $naam, $prijs, $omschrijving);

    if ($updateSuccess) {
        echo "Productgegevens succesvol bijgewerkt.";
    } else {
        echo "Er is een fout opgetreden bij het bijwerken van de productgegevens.";
    }
}
?>
