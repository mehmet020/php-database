<?php
include '../db.php'; 

class Klant {
    private $dbh;

    public function __construct($dbh) { 
        $this->dbh = $dbh;
    }

    public function insertKlant($naam, $email, $password) { 
        return $this->dbh->execute("INSERT INTO tafel (naam, email, password) 
        VALUES (?,?,?)", [$naam, $email, $password]);
    }
    public function getKlantenOverzicht() {
        return $this->dbh->query("SELECT * FROM klant")->fetchAll();
    }
    public function getKlantById($klantId) {
        $query = $this->db->prepare("SELECT * FROM klanten WHERE KlantID = ?");
        $query->bindParam(1, $klantId);
        $query->execute();
        return $query->fetch(PDO::FETCH_ASSOC);
    }
    public function updateKlant($klantId, $naam, $email, $telefoonnummer) {
        $query = $this->db->prepare("UPDATE klanten SET naam = ?, email = ?, telefoonnummer = ? WHERE KlantID = ?");
        $query->bindParam(1, $naam);
        $query->bindParam(2, $email);
        $query->bindParam(3, $telefoonnummer);
        $query->bindParam(4, $klantId);
        return $query->execute();
    }
    
    
}
?>