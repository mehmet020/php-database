<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tafel Overzicht</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Producten Overzicht</h1>
    <?php
    $dbh = new PDO('mysql:host=localhost:3307;dbname=restaurant', 'root', '');

    include 'rekening.php';

    $rekening = new rekening($dbh);

    $rekeningen = $rekening->getRekeningenOverzicht();
    
    if ($rekening) {
        echo "<table>";
        echo "<tr>
        <th>rekeningID</th>
        <th>Naam</th>
        <th>achternaam</th>
        <th>tafelnummer</th>
        <th>bedrag</th>
        </tr>";
        foreach ($rekeningen as $rekening) {
            echo "<tr>";
            echo "<td>" . $rekening['rekeningID'] . "</td>";
            echo "<td>" . $rekening['Naam'] . "</td>";
            echo "<td>" . $rekening['achternaam'] . "</td>";
            echo "<td>" . $rekening['tafelnummer'] . "</td>";
            echo "<td>" . $rekening['bedrag'] . "</td>";
            echo "<td><a href='update.php?id=" . $reservering['ReserveringsID'] . "'>Update</a></td>"; // Update-knop met een link naar een updatepagina
            echo "<td><a href='delete.php?id=" . $reservering['ReserveringsID'] . "'>Delete</a></td>"; // Verwijder-knop met een link naar een verwijderpagina
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "Geen rekeningen gevonden.";
    }
    ?>
</body>
</html>
