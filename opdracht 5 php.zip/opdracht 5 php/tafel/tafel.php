<?php

class tafel {
    private $dbh;

    public function __construct($dbh) { 
        $this->dbh = $dbh;
    }

    public function getTafelOverzicht() {
        return $this->dbh->query("SELECT * FROM tafel")->fetchAll();
    }
}
?>
