<?php
include 'product.php';

// Controleer of er een product-ID is verzonden via de URL
if(isset($_GET['id'])) {
    $productId = $_GET['id'];

    $product = new Product($myDb);
    $productInfo = $product->getProductById($productId); 
    

    if ($productInfo) {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Productgegevens bijwerken</title>
        </head>
        <body>
            <h1>Productgegevens bijwerken</h1>
            <form method="post" action="update_product_process.php">
                <input type="hidden" name="product_id" value="<?php echo $productInfo['ProductID']; ?>">
                Naam: <input type="text" name="naam" value="<?php echo $productInfo['naam']; ?>"><br>
                Prijs: <input type="text" name="prijs" value="<?php echo $productInfo['prijs']; ?>"><br>
                Omschrijving: <input type="text" name="omschrijving" value="<?php echo $productInfo['omschrijving']; ?>"><br>
                <input type="submit" value="Update">
            </form>
        </body>
        </html>
        <?php
    } else {
        echo "Product niet gevonden.";
    }
} else {
    echo "Geen product-ID opgegeven.";
}
?>
