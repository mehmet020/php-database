<?php

include '../db.php'; 

class Product{
    private $dbh;

    public function __construct($dbh) { 
        $this->dbh = $dbh;
    }

    public function insertProduct($naam, $prijs, $omschrijving) { 
        return $this->dbh->execute("INSERT INTO Product (naam, prijs, omschrijving) 
        VALUES (?,?,?)", [$naam, $prijs, $omschrijving]);
    }
    public function getProductOverzicht() {
        return $this->dbh->execute("SELECT * FROM Product")->fetchAll();
    }
    public function updateProduct($productId, $naam, $prijs, $omschrijving) {
        return $this->dbh->execute("UPDATE Product SET naam = ?, prijs = ?, omschrijving = ? WHERE ProductID = ?",[$naam, $prijs, $omschrijving, $productId]);
    }
    public function getProductById($productId) {
        return $this->dbh->execute("SELECT * FROM Product WHERE ProductID = ?",[$productId])->fetchAll();
    }
}
?>