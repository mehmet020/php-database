<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Klantgegevens bijwerken</title>
</head>
<body>
    <h1>Klantgegevens bijwerken</h1>
    <?php
    $dbh = new PDO('mysql:host=localhost:3307;dbname=restaurant', 'root', '');

    include 'klant.php';

    // Controleer of er een ID is verzonden via de URL
    if(isset($_GET['id'])) {
        $klantId = $_GET['id'];
        $klant = new Klant($dbh);
        $klantInfo = $klant->getKlantById($klantId); // Haal klantgegevens op op basis van ID

        if ($klantInfo) {
            // Weergave van het formulier voor het bijwerken van klantgegevens
            echo "<form method='post' action='update_process.php'>";
            echo "<input type='hidden' name='klant_id' value='" . $klantInfo['KlantID'] . "'>";
            echo "Naam: <input type='text' name='naam' value='" . $klantInfo['naam'] . "'><br>";
            echo "Email: <input type='email' name='email' value='" . $klantInfo['email'] . "'><br>";
            echo "Telefoonnummer: <input type='text' name='telefoonnummer' value='" . $klantInfo['telefoonnummer'] . "'><br>";
            echo "<input type='submit' value='Update'>";
            echo "</form>";
        } else {
            echo "Klant niet gevonden.";
        }
    } else {
        echo "Geen klant-ID opgegeven.";
    }
    ?>
</body>
</html>
