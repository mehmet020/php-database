<?php
$dbh = new PDO('mysql:host=localhost:3307;dbname=restaurant', 'root', '');

include 'klant.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $klantId = $_POST['klant_id'];
    $naam = $_POST['naam'];
    $email = $_POST['email'];
    $telefoonnummer = $_POST['telefoonnummer'];

    $klant = new Klant($dbh);
    $updateSuccess = $klant->updateKlant($klantId, $naam, $email, $telefoonnummer);

    if ($updateSuccess) {
        echo "Klantgegevens succesvol bijgewerkt.";
    } else {
        echo "Er is een fout opgetreden bij het bijwerken van de klantgegevens.";
    }
}
?>
