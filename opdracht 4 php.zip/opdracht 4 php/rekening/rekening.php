<?php

include '../db.php'; 

class rekening {
    private $dbh;

    public function __construct(restaurant $dbh) { 
        $this->dbh = $dbh;
    }

    public function insertrekening ($naam, $achternaam, $tafelnummer, $bedrag) { 
        return $this->dbh->execute("INSERT INTO rekening (naam, achternaam, tafelnummer,bedrag) 
        VALUES (?,?,?,?)", [$naam, $achternaam, $tafelnummer, $bedrag]);
    }
}
?>