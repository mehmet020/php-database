<?php
include '../db.php'; 
include '../header.php';
$Product = new Product($myDb);

class Product{
    private $dbh;

    public function __construct(restaurant $dbh) { 
        $this->dbh = $dbh;
    }

    public function insertProduct($naam, $prijs, $omschrijving) { 
        return $this->dbh->execute("INSERT INTO Product (naam, prijs, omschrijving) 
        VALUES (?,?,?)", [$naam, $prijs, $omschrijving]);
    }
}

    if ($_SERVER['REQUEST_METHOD'] == 'POST' ) {

        try {
            $Product->insertProduct($_POST['naam'],$_POST['prijs'], $_POST['omschrijving'],);
            echo "Success";
            } catch (Exception $e) {
                echo 'Error: ' . $e->getMessage();
            }
        }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.9/css/unicons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <form method="POST" action="">
        <div id="stars"></div>
        <div id="stars2"></div>
        <div id="stars3"></div>
        <div class="section">
            <div class="container">
                <div class="row full-height justify-content-center">
                    <div class="col-12 text-center align-self-center py-5">
                        <div class="section pb-5 pt-5 pt-sm-2 text-center">
                            <input class="checkbox" type="checkbox" id="reg-log" name="reg-log"/>
                            <div class="card-3d-wrap mx-auto">
                                <div class="card-3d-wrapper">
                                    <div class="card-front">
                                        <div class="center-wrap">
                                            <div class="section text-center">
                                                <h4 class="mb-4 pb-3">Voer product in</h4>

                                                <div class="form-group mt-2">
                                                    <input type="text" class="form-style" placeholder="naam" name="naam">
                                                </div> 
                                                <div class="form-group mt-2">
                                                    <input type="text" class="form-style" placeholder="prijs" name="prijs">
                                                </div> 
                                                <div class="form-group mt-2">
                                                    <input type="text" class="form-style" placeholder="omschrijving" name="omschrijving">
                                                </div> 
                                                <button type="submit" class="btn mt-4">product</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</body>
</html>

