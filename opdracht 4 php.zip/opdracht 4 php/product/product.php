<?php

include '../db.php'; 

class Product{
    private $dbh;

    public function __construct(restaurant $dbh) { 
        $this->dbh = $dbh;
    }

    public function insertProduct($naam, $prijs, $omschrijving) { 
        return $this->dbh->execute("INSERT INTO Product (naam, prijs, omschrijving) 
        VALUES (?,?,?)", [$naam, $prijs, $omschrijving]);
    }
}
?>