<?php

include '../db.php'; 

class tafel {
    private $dbh;

    public function __construct(restaurant $dbh) { 
        $this->dbh = $dbh;
    }

    public function inserttafel($naam, $achternaam, $tafelnummer) { 
        return $this->dbh->execute("INSERT INTO tafel (naam, achternaam, tafelnummer) 
        VALUES (?,?,?)", [$naam, $achternaam, $tafelnummer]);
    }
}
?>